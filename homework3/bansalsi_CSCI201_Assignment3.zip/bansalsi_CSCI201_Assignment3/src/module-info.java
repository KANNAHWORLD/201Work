module bansalsi_CSCI201_Assignment3 {
	requires com.google.common;
	requires com.google.gson;
	requires java.net.http;
	opens bansalsi_CSCI201_Assignment3 to com.google.gson;
}